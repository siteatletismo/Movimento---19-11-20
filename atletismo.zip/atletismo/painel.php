<?php
session_start ();
incluir ('verifica_login.php');
?>

<h2> Olá, <?php echo  $_SESSION ['email'];?></h2>
<H2> <a href = "logout.php"> Sair </a> </h2>

