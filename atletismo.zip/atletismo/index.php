<!DOCTYPE HTML>
<!--
	Hielo by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title> Atletismo </title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header" class="alt">
				<div class="logo"><a href="index.html"> MOVIMENTE-SE <span></span></a></div>
				<a href="#menu">Menu</a>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="generic.php"> Perfil </a></li>
                    <li><a href="elements.html">Elements</a></li>
                    <li><a href="cadastroUsuario.php"> Cadastro</a></li>
                    <li><a href="login_index.php"> Login </a></li>
				</ul>
			</nav>

		<!-- Banner -->
			<section class="banner full">
				<article>
					<img  src = "images/foto1.jpg" alt = "" />
					<div class="inner">
						<header>
							<p>Venha crscer conosco </p>
							<h2>Movimento</h2>
						</header>
					</div>
				</article>

				<artigo >
					<img  src = "images/foto2.jpg" alt = "" />
					<div  class = " inner " >
						<cabeçalho >
							<p > Melhore seu rendimento nos treinos </p >
							<h2 > Movimento </h2 >
						</header >
					</div >
				</artigo >
				<article>
					<img src="images/foto3.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>Acompanhe sua evolução com gráficos e tabelas</p>
							<h2> Movimento</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="images/foto4.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>Monte uma equipe de treinamento </p>
							<h2>Movimento</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="images/foto5.jpg"  alt="" />
					<div class="inner">
						<header>
							<p></p>
							<h2>Movimento</h2>
						</header>
					</div>
				</article>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style2">
				<div class="inner">
					<div class="grid-style">

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/card1.jpg" alt="" />
								</div>
								<div class="content">
									<header class="align-center">
										<p>Marque seus andamentos, saltos e lançamentos</p>
										<h2>Acompanhe sua evolução </h2>
									</header>
									<p> Clique aqui para registrar seu andamento nas modalidades, não deixe de nos informar como está o seu desenvolvimento! </p>
									<footer class="align-center">
										<a href="#" class="button alt">Learn More</a>
									</footer>
								</div>
							</div>
						</div>

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/card2.jpg" alt="" />
								</div>
								<div class="content">
									<header class="align-center">
										<p>mattis elementum sapien pretium tellus</p>
										<h2>Arremessos </h2>
									</header>
									<p> Arremesso é uma modalidade olímpica de atletismo, onde os atletas competem para arremessar um objeto o mais longe possível. As qualidades principais do atleta campeão são a força e a aceleração. Os tipos de arremesso são: Arremesso de peso, arremesso de dardo, arremesso de martelo e arremesso de disco. </p>
									<footer class="align-center">
										<a href="#" class="button alt">Learn More</a>
									</footer>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<p>Nam vel ante sit amet libero scelerisque facilisis eleifend vitae urna</p>
						<h2>Movimento</h2>
					</header>
				</div>
			</section>

		<!-- Three -->
			<section id="one" class="wrapper style2">
				<div class="inner">
					<div class="grid-style">

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/card3.jpg" alt="" />
								</div>
								<div class="content">
									<header class="align-center">
										<p>maecenas sapien feugiat ex purus</p>
										<h2>Saltos</h2>
									</header>
									<p> Salto é uma modalidade olímpica de atletismo onde os atletas combinam velocidade, força e agilidade para saltarem o mais longe possível a partir de um ponto pré-determinado. Existem 4 tipos de salto: salto em distância, salto triplo, salto em altura e salto com vara.</p>
									<footer class="align-center">
										<a href="#" class="button alt">Learn More</a>
									</footer>
								</div>
							</div>
						</div>

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/card4.jpg" alt="" />
								</div>
								<div class="content">
									<header class="align-center">
										<p>mattis elementum sapien pretium tellus</p>
										<h2>Corridas </h2>
									</header>
									<p> A corrida envolve estratégia, técnica e bom condicionamento físico do atleta. As corridas são divididas em curta distância ou de velocidade; média distância ou de meio fundo; e longa distância ou de fundo. A pista de corrida contém oito raias, com largura mínima de dez metros. A pista oficial de atletismo é composta de duas retas e duas curvas.</p>
									<footer class="align-center">
										<a href="#" class="button alt">Learn More</a>
									</footer>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section>


		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
					</ul>
				</div>
				<div class="copyright">
					&copy; Untitled. All rights reserved.
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>

